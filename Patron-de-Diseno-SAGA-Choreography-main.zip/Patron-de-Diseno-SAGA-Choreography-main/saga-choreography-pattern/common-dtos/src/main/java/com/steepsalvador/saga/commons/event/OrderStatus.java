package com.steepsalvador.saga.commons.event;

public enum OrderStatus {

    ORDER_CREATED,ORDER_COMPLETED,ORDER_CANCELLED
}
