﻿/// <reference path="modernizr-2.8.3.js" />
/// <reference path="jquery-ui-1.11.4.js" />
/// <reference path="jquery-2.2.3.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="knockout-2.2.0.debug.js" />
