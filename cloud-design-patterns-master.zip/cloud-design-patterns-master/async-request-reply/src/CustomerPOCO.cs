namespace Contoso
{
    public class CustomerPOCO
    {
        public string id { get; set; }
        public string customername { get; set; }
    }
}