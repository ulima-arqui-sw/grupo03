﻿
namespace PackageService.Services
{
    public static class DocumentConfig
    {
        public static string DatabaseId { get; set; } 

        public static string CollectionId { get; set;  } 
    }
}
