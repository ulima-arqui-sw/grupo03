package com.fabrikam.dronedelivery.ingestion.models;

public enum ContainerSize {
	Small, 
	Medium, 
	Large 
}
