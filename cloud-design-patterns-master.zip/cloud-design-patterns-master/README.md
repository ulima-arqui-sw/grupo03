# Cloud Design Patterns

Microsoft patterns & practices

This is companion code for the article series found in the [Cloud Design Patterns](https://aka.ms/cloud-design-patterns) series in Azure Architecture Center.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/). For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.